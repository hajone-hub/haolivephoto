# Hạo Live Photo (Android)

Chụp ảnh động giống Live Photo của iPhone: mỗi lần bấm chụp, app giữ lại ~1,5 giây TRƯỚC và ghi tiếp ~1,5 giây SAU.

Mỗi lần chụp tạo ra:
- `Pictures/HaoLivePhoto/HaoLive_xxx.jpg`: ảnh động (Motion Photo: JPEG + video nhúng). Google Photos nhấn giữ để xem chuyển động.
- `Movies/HaoLivePhoto/HaoLive_xxx.mp4`: video ~3 giây (không âm thanh) để đăng TikTok.

Nút **Đăng TikTok** gửi file MP4 sang TikTok (bản `com.ss.android.ugc.trill` hoặc `com.zhiliaoapp.musically`).

## Build APK
Mở thư mục bằng Android Studio rồi Build > Build APK(s), hoặc dùng GitHub Actions (xem hướng dẫn trong chat).

## Code
- `LiveRecorder.kt`: nhận khung hình từ CameraX, mã hóa H.264 liên tục vào bộ đệm vòng 3,5 giây, ghép MP4 khi chụp.
- `MotionPhoto.kt`: nhúng XMP và nối MP4 vào cuối JPEG (định dạng Motion Photo của Google).
- `MediaSaver.kt`: lưu vào Thư viện (MediaStore) và gửi sang TikTok.
- `MainActivity.kt`: giao diện camera, nút LIVE, đổi camera, thẻ kết quả.
