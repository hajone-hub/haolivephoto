package com.haolive.photo

import java.io.ByteArrayOutputStream

/**
 * Ghép ảnh JPEG + video MP4 thành "Motion Photo" (định dạng của Google/Android):
 * JPEG + khối XMP mô tả + MP4 nối ở cuối file. Google Photos và một số ứng dụng Thư viện sẽ phát ảnh động khi nhấn giữ.
 */
object MotionPhoto {

    fun build(jpeg: ByteArray, mp4: ByteArray, presentationUs: Long): ByteArray {
        if (jpeg.size < 4 || jpeg[0] != 0xFF.toByte() || jpeg[1] != 0xD8.toByte()) return jpeg

        val header = "http://ns.adobe.com/xap/1.0/\u0000".toByteArray(Charsets.US_ASCII)
        val xmp = xmpPacket(mp4.size, presentationUs).toByteArray(Charsets.UTF_8)
        val segLen = 2 + header.size + xmp.size // độ dài đoạn APP1 gồm cả 2 byte độ dài
        if (segLen > 0xFFFF) return jpeg

        val insertAt = skipLeadingApp(jpeg)
        val out = ByteArrayOutputStream(jpeg.size + mp4.size + segLen + 8)
        out.write(jpeg, 0, insertAt)
        out.write(0xFF)
        out.write(0xE1)
        out.write(segLen shr 8)
        out.write(segLen and 0xFF)
        out.write(header, 0, header.size)
        out.write(xmp, 0, xmp.size)
        out.write(jpeg, insertAt, jpeg.size - insertAt)
        out.write(mp4, 0, mp4.size)
        return out.toByteArray()
    }

    /** Vị trí ngay sau các đoạn APP0 (JFIF) / APP1 (Exif) ở đầu file, để chèn XMP vào sau đó. */
    private fun skipLeadingApp(j: ByteArray): Int {
        var pos = 2
        while (pos + 4 <= j.size && j[pos] == 0xFF.toByte()) {
            val marker = j[pos + 1].toInt() and 0xFF
            val len = ((j[pos + 2].toInt() and 0xFF) shl 8) or (j[pos + 3].toInt() and 0xFF)
            val isJfif = marker == 0xE0
            val isExif = marker == 0xE1 && pos + 10 <= j.size &&
                String(j, pos + 4, 4, Charsets.US_ASCII) == "Exif"
            if (!isJfif && !isExif) break
            if (pos + 2 + len > j.size) break
            pos += 2 + len
        }
        return pos
    }

    private fun xmpPacket(videoLen: Int, presentationUs: Long): String = """<?xpacket begin="${'\uFEFF'}" id="W5M0MpCehiHzreSzNTczkc9d"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.1.0-jc003">
 <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <rdf:Description rdf:about=""
    xmlns:GCamera="http://ns.google.com/photos/1.0/camera/"
    xmlns:Container="http://ns.google.com/photos/1.0/container/"
    xmlns:Item="http://ns.google.com/photos/1.0/container/item/"
    GCamera:MicroVideo="1"
    GCamera:MicroVideoVersion="1"
    GCamera:MicroVideoOffset="$videoLen"
    GCamera:MicroVideoPresentationTimestampUs="$presentationUs"
    GCamera:MotionPhoto="1"
    GCamera:MotionPhotoVersion="1"
    GCamera:MotionPhotoPresentationTimestampUs="$presentationUs">
   <Container:Directory>
    <rdf:Seq>
     <rdf:li rdf:parseType="Resource">
      <Container:Item Item:Mime="image/jpeg" Item:Semantic="Primary" Item:Length="0" Item:Padding="0"/>
     </rdf:li>
     <rdf:li rdf:parseType="Resource">
      <Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto" Item:Length="$videoLen" Item:Padding="0"/>
     </rdf:li>
    </rdf:Seq>
   </Container:Directory>
  </rdf:Description>
 </rdf:RDF>
</x:xmpmeta>
<?xpacket end="w"?>"""
}
