package com.haolive.photo

import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import androidx.camera.core.ImageProxy
import java.io.File
import java.nio.ByteBuffer
import java.util.ArrayDeque

/**
 * Ghi hình liên tục vào bộ đệm vòng (khoảng 3,5 giây đã mã hóa H.264).
 * Khi bấm chụp: giữ lại ~1,5 giây TRƯỚC và ghi tiếp ~1,5 giây SAU, rồi ghép thành MP4 (giống Live Photo của iPhone).
 */
class LiveRecorder {

    class Sample(val ptsUs: Long, val key: Boolean, val data: ByteArray)

    private class Snap(val samples: List<Sample>, val fmt: MediaFormat?, val rot: Int, val shutter: Long)

    /** stillOffsetUs: thời điểm bấm chụp tính từ đầu clip. */
    class Clip(val file: File, val stillOffsetUs: Long)

    companion object {
        const val PRE_US = 1_500_000L
        const val POST_US = 1_500_000L
        const val KEEP_US = 3_500_000L
    }

    private val codecLock = Any()
    private val lock = Any()
    private val ring = ArrayDeque<Sample>()

    private var codec: MediaCodec? = null
    private var outFormat: MediaFormat? = null
    private var curW = 0
    private var curH = 0
    private var rotation = 0
    private var newestOutPts = 0L
    private var capturing = false
    private var shutterPts = 0L
    private var failures = 0
    private val info = MediaCodec.BufferInfo()

    @Volatile
    private var lastPts = 0L

    /** false nếu máy không hỗ trợ ghi Live (chỉ chụp ảnh thường). */
    @Volatile
    var supported = true
        private set

    fun isReady(): Boolean = supported && codec != null

    // ---------------- Nhận khung hình từ camera ----------------
    fun onFrame(image: ImageProxy) {
        synchronized(codecLock) {
            try {
                if (!supported) return
                val w = image.width
                val h = image.height
                val rot = image.imageInfo.rotationDegrees
                val ptsUs = image.imageInfo.timestamp / 1000
                lastPts = ptsUs

                if (codec == null || w != curW || h != curH || rot != rotation) {
                    if (!startEncoder(w, h, rot)) {
                        supported = false
                        return
                    }
                }
                val c = codec ?: return
                val idx = c.dequeueInputBuffer(0)
                if (idx >= 0) {
                    val dst = c.getInputImage(idx)
                    if (dst == null) {
                        supported = false
                        return
                    }
                    copyPlanes(image, dst)
                    c.queueInputBuffer(idx, 0, w * h * 3 / 2, ptsUs, 0)
                }
                drain(c)
            } catch (e: Exception) {
                failures++
                releaseLocked()
                if (failures >= 3) supported = false
            } finally {
                image.close()
            }
        }
    }

    private fun startEncoder(w: Int, h: Int, rot: Int): Boolean {
        releaseLocked()
        return try {
            val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, 8_000_000)
            fmt.setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            c.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            c.start()
            synchronized(lock) {
                codec = c
                curW = w
                curH = h
                rotation = rot
                outFormat = null
                ring.clear()
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Chép 3 mặt phẳng Y, U, V từ khung camera sang bộ đệm đầu vào của bộ mã hóa (xử lý đúng stride). */
    private fun copyPlanes(src: ImageProxy, dst: Image) {
        val w = minOf(src.width, dst.width)
        val h = minOf(src.height, dst.height)
        for (p in 0 until 3) {
            val s = src.planes[p]
            val d = dst.planes[p]
            val pw = if (p == 0) w else w / 2
            val ph = if (p == 0) h else h / 2
            val sb = s.buffer
            val db = d.buffer
            val sRow = s.rowStride
            val sPix = s.pixelStride
            val dRow = d.rowStride
            val dPix = d.pixelStride
            if (sPix == 1 && dPix == 1) {
                val row = ByteArray(pw)
                for (r in 0 until ph) {
                    sb.position(r * sRow)
                    sb.get(row, 0, pw)
                    db.position(r * dRow)
                    db.put(row, 0, pw)
                }
            } else {
                for (r in 0 until ph) {
                    val sBase = r * sRow
                    val dBase = r * dRow
                    for (c in 0 until pw) {
                        db.put(dBase + c * dPix, sb.get(sBase + c * sPix))
                    }
                }
            }
        }
    }

    private fun drain(c: MediaCodec) {
        while (true) {
            val i = c.dequeueOutputBuffer(info, 0)
            if (i == MediaCodec.INFO_TRY_AGAIN_LATER) return
            if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                synchronized(lock) { outFormat = c.outputFormat }
            } else if (i >= 0) {
                val buf = c.getOutputBuffer(i)
                val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                if (buf != null && info.size > 0 && !isConfig) {
                    val data = ByteArray(info.size)
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    buf.get(data)
                    val key = (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
                    addSample(Sample(info.presentationTimeUs, key, data))
                }
                c.releaseOutputBuffer(i, false)
            }
        }
    }

    private fun addSample(s: Sample) {
        synchronized(lock) {
            ring.addLast(s)
            newestOutPts = s.ptsUs
            if (!capturing) {
                while (true) {
                    val f = ring.peekFirst() ?: break
                    if (f.ptsUs < s.ptsUs - KEEP_US) ring.pollFirst() else break
                }
            }
        }
    }

    // ---------------- Chụp ----------------
    /** Gọi ngay lúc bấm nút chụp. Trả về false nếu chưa sẵn sàng ghi Live. */
    fun begin(): Boolean = synchronized(lock) {
        if (!supported || codec == null) {
            false
        } else {
            capturing = true
            shutterPts = lastPts
            true
        }
    }

    fun cancel() {
        synchronized(lock) { capturing = false }
    }

    /** Đợi ghi xong phần "sau", rồi ghép thành MP4. Chạy ở luồng nền. Trả về null nếu không ghép được. */
    fun finish(out: File): Clip? {
        try {
            val deadline = System.currentTimeMillis() + 5000
            while (System.currentTimeMillis() < deadline) {
                val done = synchronized(lock) { newestOutPts >= shutterPts + POST_US }
                if (done) break
                Thread.sleep(40)
            }

            val state = synchronized(lock) { Snap(ArrayList(ring), outFormat, rotation, shutterPts) }
            val snap = state.samples
            val fmt = state.fmt
            val rot = state.rot
            val shutter = state.shutter
            if (fmt == null || snap.isEmpty()) return null

            var startIdx = snap.indexOfLast { it.key && it.ptsUs <= shutter - PRE_US }
            if (startIdx < 0) startIdx = snap.indexOfFirst { it.key }
            if (startIdx < 0) return null

            val clip = snap.subList(startIdx, snap.size).filter { it.ptsUs <= shutter + POST_US }
            if (clip.size < 5) return null

            val base = clip[0].ptsUs
            val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            try {
                val track = muxer.addTrack(fmt)
                muxer.setOrientationHint(rot)
                muxer.start()
                val bi = MediaCodec.BufferInfo()
                for (s in clip) {
                    bi.set(0, s.data.size, s.ptsUs - base, if (s.key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    muxer.writeSampleData(track, ByteBuffer.wrap(s.data), bi)
                }
                muxer.stop()
            } finally {
                muxer.release()
            }
            return Clip(out, maxOf(0L, shutter - base))
        } catch (e: Exception) {
            return null
        } finally {
            synchronized(lock) { capturing = false }
        }
    }

    // ---------------- Dọn dẹp ----------------
    fun release() {
        synchronized(codecLock) { releaseLocked() }
    }

    private fun releaseLocked() {
        val c = codec
        codec = null
        if (c != null) {
            try { c.stop() } catch (e: Exception) { /* bỏ qua */ }
            try { c.release() } catch (e: Exception) { /* bỏ qua */ }
        }
        synchronized(lock) {
            ring.clear()
            outFormat = null
            capturing = false
        }
    }
}
