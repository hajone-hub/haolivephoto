package com.haolive.photo

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.IOException

object MediaSaver {

    private const val FOLDER = "HaoLivePhoto"

    /** Lưu ảnh JPEG (hoặc Motion Photo) vào Thư viện: Pictures/HaoLivePhoto. */
    fun saveImage(ctx: Context, data: ByteArray, name: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + FOLDER)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values)
            ?: throw IOException("Không tạo được ảnh trong Thư viện")
        try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("Không ghi được ảnh")
            out.use { it.write(data) }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    /** Lưu video MP4 vào Thư viện: Movies/HaoLivePhoto (dùng để đăng TikTok). */
    fun saveVideo(ctx: Context, file: File, name: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/" + FOLDER)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values)
            ?: throw IOException("Không tạo được video trong Thư viện")
        try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("Không ghi được video")
            file.inputStream().use { input -> out.use { output -> input.copyTo(output) } }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    /** Gửi video sang TikTok (bản Việt Nam/Đông Nam Á hoặc bản quốc tế). Không có thì mở menu chia sẻ. */
    fun shareToTikTok(activity: Activity, video: Uri) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, video)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val pm = activity.packageManager
        val pkg = listOf("com.ss.android.ugc.trill", "com.zhiliaoapp.musically").firstOrNull {
            try {
                pm.getPackageInfo(it, 0)
                true
            } catch (e: Exception) {
                false
            }
        }
        if (pkg != null) {
            send.setPackage(pkg)
            try {
                activity.startActivity(send)
                return
            } catch (e: ActivityNotFoundException) {
                send.setPackage(null)
            }
        }
        activity.startActivity(Intent.createChooser(send, "Đăng video lên…"))
    }
}
