package com.haolive.photo

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.util.Size
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var hintView: TextView
    private lateinit var btnLive: TextView
    private lateinit var resultCard: LinearLayout
    private lateinit var resultText: TextView
    private lateinit var btnTikTok: TextView
    private lateinit var thumb: ImageView

    private var cameraProvider: ProcessCameraProvider? = null
    private var imageCapture: ImageCapture? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var liveOn = true
    private var busy = false

    private var lastVideoUri: Uri? = null
    private var lastPhotoUri: Uri? = null

    private val recorder = LiveRecorder()
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val worker = Executors.newSingleThreadExecutor()

    private val askCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else showHint("Cần cấp quyền Camera để chụp ảnh.", 0)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        hintView = findViewById(R.id.hintView)
        btnLive = findViewById(R.id.btnLive)
        resultCard = findViewById(R.id.resultCard)
        resultText = findViewById(R.id.resultText)
        btnTikTok = findViewById(R.id.btnTikTok)
        thumb = findViewById(R.id.thumb)

        findViewById<View>(R.id.shutter).setOnClickListener { onShutter() }
        btnLive.setOnClickListener { toggleLive() }
        findViewById<View>(R.id.btnFlip).setOnClickListener { flipCamera() }
        findViewById<View>(R.id.btnView).setOnClickListener { openLast() }
        btnTikTok.setOnClickListener { lastVideoUri?.let { MediaSaver.shareToTikTok(this, it) } }
        thumb.setOnClickListener { openLast() }

        if (hasCamera()) startCamera() else askCamera.launch(Manifest.permission.CAMERA)
    }

    override fun onPause() {
        super.onPause()
        recorder.release() // camera dừng khi rời app; bộ đệm cũ không còn giá trị
    }

    override fun onDestroy() {
        super.onDestroy()
        recorder.release()
        analysisExecutor.shutdown()
        worker.shutdown()
    }

    private fun hasCamera() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    // ---------------- Camera ----------------
    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider = future.get()
            bindUseCases()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindUseCases() {
        val provider = cameraProvider ?: return

        val preview = Preview.Builder().build()
        preview.setSurfaceProvider(previewView.surfaceProvider)

        val capture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()

        val selector = ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(
                ResolutionStrategy(Size(1280, 720), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
            )
            .build()
        val analysis = ImageAnalysis.Builder()
            .setResolutionSelector(selector)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
        analysis.setAnalyzer(analysisExecutor) { image -> recorder.onFrame(image) }

        try {
            provider.unbindAll()
            recorder.release()
            val camSelector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            provider.bindToLifecycle(this, camSelector, preview, capture, analysis)
            imageCapture = capture
        } catch (e: Exception) {
            showHint("Không mở được camera: " + (e.message ?: "lỗi"), 0)
        }
    }

    private fun flipCamera() {
        if (busy) return
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }
        bindUseCases()
    }

    private fun toggleLive() {
        liveOn = !liveOn
        if (liveOn) {
            btnLive.text = "● LIVE"
            btnLive.setTextColor(getColor(R.color.live))
        } else {
            btnLive.text = "LIVE TẮT"
            btnLive.setTextColor(getColor(R.color.muted))
        }
    }

    // ---------------- Chụp ----------------
    private fun onShutter() {
        if (!hasCamera()) {
            askCamera.launch(Manifest.permission.CAMERA)
            return
        }
        val capture = imageCapture ?: return
        if (busy) return
        busy = true
        resultCard.visibility = View.GONE

        val live = liveOn && recorder.begin()
        if (liveOn && !live && !recorder.supported) {
            showHint("Máy không hỗ trợ ghi Live, sẽ chụp ảnh thường.", 3000)
        }
        if (live) showHint("Giữ yên…", 0)

        val still = File(cacheDir, "still_" + System.currentTimeMillis() + ".jpg")
        capture.takePicture(
            ImageCapture.OutputFileOptions.Builder(still).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    process(still, live)
                }

                override fun onError(exception: ImageCaptureException) {
                    recorder.cancel()
                    busy = false
                    showHint("Chụp thất bại: " + (exception.message ?: "lỗi"), 3000)
                }
            }
        )
    }

    private fun process(still: File, live: Boolean) {
        worker.execute {
            try {
                if (live) runOnUiThread { showHint("Đang xử lý…", 0) }
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val name = "HaoLive_$stamp"
                val stillBytes = still.readBytes()

                val clip = if (live) recorder.finish(File(cacheDir, "clip_$stamp.mp4")) else null

                val photo: Uri
                val video: Uri?
                val message: String
                if (clip != null) {
                    val mp4 = clip.file.readBytes()
                    val motion = MotionPhoto.build(stillBytes, mp4, clip.stillOffsetUs)
                    photo = MediaSaver.saveImage(this, motion, "$name.jpg")
                    video = MediaSaver.saveVideo(this, clip.file, "$name.mp4")
                    clip.file.delete()
                    message = "Đã lưu Live Photo"
                } else {
                    photo = MediaSaver.saveImage(this, stillBytes, "$name.jpg")
                    video = null
                    message = if (live) "Không ghi được chuyển động, đã lưu ảnh thường" else "Đã lưu ảnh"
                }

                val thumbSource: Uri = video ?: photo
                val bmp: Bitmap? = try {
                    contentResolver.loadThumbnail(thumbSource, Size(256, 256), null)
                } catch (e: Exception) {
                    null
                }
                runOnUiThread { onSaved(photo, video, message, bmp) }
            } catch (e: Exception) {
                runOnUiThread {
                    busy = false
                    showHint("Lưu thất bại: " + (e.message ?: "lỗi"), 4000)
                }
            } finally {
                still.delete()
            }
        }
    }

    private fun onSaved(photo: Uri?, video: Uri?, message: String, bmp: Bitmap?) {
        busy = false
        lastPhotoUri = photo
        lastVideoUri = video
        hintView.visibility = View.GONE
        resultText.text = message
        btnTikTok.visibility = if (video != null) View.VISIBLE else View.GONE
        resultCard.visibility = View.VISIBLE
        if (bmp != null) thumb.setImageBitmap(bmp)
    }

    private fun openLast() {
        val uri = lastVideoUri ?: lastPhotoUri ?: return
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, contentResolver.getType(uri))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Hãy mở trong ứng dụng Thư viện.", Toast.LENGTH_SHORT).show()
        }
    }

    /** Hiện thông báo nhỏ; autoHideMs = 0 thì giữ đến khi có thông báo khác. */
    private fun showHint(text: String, autoHideMs: Long) {
        hintView.text = text
        hintView.visibility = View.VISIBLE
        if (autoHideMs > 0) {
            hintView.postDelayed({
                if (hintView.text == text) hintView.visibility = View.GONE
            }, autoHideMs)
        }
    }

}
